using System.ComponentModel.DataAnnotations;
using OrderHub.Domain.Enums;
using OrderHub.Web;

namespace OrderHub.Web.Models.PlatformConnections;

public sealed class CreatePlatformConnectionViewModel
{
    [Required(ErrorMessageResourceType = typeof(SharedResource), ErrorMessageResourceName = "Validation.PlatformRequired")]
    [Display(Name = "PlatformConnections.Platform", ResourceType = typeof(SharedResource))]
    public FoodPlatform Platform { get; set; }

    [Required(ErrorMessageResourceType = typeof(SharedResource), ErrorMessageResourceName = "Validation.StoreIdRequired")]
    [Display(Name = "PlatformConnections.StoreId", ResourceType = typeof(SharedResource))]
    public string StoreId { get; set; } = string.Empty;

    [Required(ErrorMessageResourceType = typeof(SharedResource), ErrorMessageResourceName = "Validation.ApiKeyRequired")]
    [Display(Name = "PlatformConnections.ApiKey", ResourceType = typeof(SharedResource))]
    public string ApiKey { get; set; } = string.Empty;

    [Required(ErrorMessageResourceType = typeof(SharedResource), ErrorMessageResourceName = "Validation.ApiSecretRequired")]
    [Display(Name = "PlatformConnections.ApiSecret", ResourceType = typeof(SharedResource))]
    public string ApiSecret { get; set; } = string.Empty;

    [Display(Name = "Common.Active", ResourceType = typeof(SharedResource))]
    public bool IsActive { get; set; } = true;
}

