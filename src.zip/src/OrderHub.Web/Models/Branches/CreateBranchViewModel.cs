using System.ComponentModel.DataAnnotations;
using OrderHub.Web;

namespace OrderHub.Web.Models.Branches;

public sealed class CreateBranchViewModel
{
    [Required(ErrorMessageResourceType = typeof(SharedResource), ErrorMessageResourceName = "Validation.BranchNameRequired")]
    [Display(Name = "Branches.Name", ResourceType = typeof(SharedResource))]
    public string Name { get; set; } = string.Empty;

    [Required(ErrorMessageResourceType = typeof(SharedResource), ErrorMessageResourceName = "Validation.AddressRequired")]
    [Display(Name = "Branches.Address", ResourceType = typeof(SharedResource))]
    public string Address { get; set; } = string.Empty;

    [Display(Name = "Common.Active", ResourceType = typeof(SharedResource))]
    public bool IsActive { get; set; } = true;
}

