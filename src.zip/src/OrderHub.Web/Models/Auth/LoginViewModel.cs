using System.ComponentModel.DataAnnotations;
using OrderHub.Web;

namespace OrderHub.Web.Models.Auth;

public sealed class LoginViewModel
{
    [Required(ErrorMessageResourceType = typeof(SharedResource), ErrorMessageResourceName = "Validation.EmailRequired")]
    [EmailAddress(ErrorMessageResourceType = typeof(SharedResource), ErrorMessageResourceName = "Validation.EmailInvalid")]
    [Display(Name = "Auth.Email", ResourceType = typeof(SharedResource))]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessageResourceType = typeof(SharedResource), ErrorMessageResourceName = "Validation.PasswordRequired")]
    [Display(Name = "Auth.Password", ResourceType = typeof(SharedResource))]
    public string Password { get; set; } = string.Empty;

    public string? ReturnUrl { get; set; }
}

